class ApiConstants {
  static const String accessToken = 'desmatippus';
  static const String baseUrl = 'https://beta.mrdekk.ru/todobackend';
  static const String listEndpoint = '/list/';
}
