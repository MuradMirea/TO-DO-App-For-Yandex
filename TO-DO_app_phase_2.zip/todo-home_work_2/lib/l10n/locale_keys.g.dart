// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const appTitle = 'appTitle';
  static const completed = 'completed';
  static const newTask = 'newTask';
  static const addTask = 'addTask';
  static const SAVE = 'SAVE';
  static const whatToDo = 'whatToDo';
  static const importance = 'importance';
  static const no = 'no';
  static const low = 'low';
  static const high = 'high';
  static const deadline = 'deadline';
  static const delete = 'delete';
  static const DONE = 'DONE';
  static const emptyTask = 'emptyTask';
  static const smthgWentWrong = 'smthgWentWrong';
  static const refreshPage = 'refreshPage';

}
